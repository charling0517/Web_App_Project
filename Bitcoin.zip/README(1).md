# Bitbank

这个项目是什么什么，自己填充一下

## 安装

- python3.5+
- MySQL
- python包（使用pip进行安装）：coinbase,MySQL-python,mysql-connector,flask
- js插件（无需安装）：[echarts](http://echarts.baidu.com/echarts2/doc/example.html),[Datatables](https://datatables.net/),[Bootstrap](http://getbootstrap.com/)

## 运行

- 在MySQL中创建数据库bitcoin（charset设置为utf8）
- 将bitcoin.sql导入数据库
- 进入根目录，执行命令：python bitcoin.py

## 联系方式

admin123@nyu.edu

